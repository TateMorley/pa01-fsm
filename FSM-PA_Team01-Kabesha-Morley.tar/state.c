//---------------------------------------------------------
// Assignment : Lab-02 Opening Source
// Date : 9/10/25
//
// Author : FSM-PA_Team01
//
// File Name : state.c
//---------------------------------------------------------

#include <stdlib.h>
#include "state.h"

state_t * default_event_handler()
{
  return NULL;
}

void default_action()
{
}
