//---------------------------------------------------------
// Assignment : Lab-02 Opening Source
// Date : 9/10/25
//
// Author : FSM-PA_Team01
//
// File Name : accepting.h
//---------------------------------------------------------

#ifndef accepting_h
#define accepting_h

#include "state.h"

void getOrderSize();
state_t* resetAttempts();

#endif
