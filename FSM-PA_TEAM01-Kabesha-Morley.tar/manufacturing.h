//---------------------------------------------------------
// Assignment : Lab-02 Opening Source
// Date : 9/10/25
// 
// Author : FSM-PA_Team01
//
// File Name : closed.c
//---------------------------------------------------------

#ifndef manufacturing_h
#define manufacturing_h

#include "state.h"

state_t* chargeClient();

void entryToManufacturing();
void exitFromManufacturing();

void dispatchFactoryLines();
void shutDownFactoryLines();

#endif
